public class Card {
    private String function;
    Card(String function){
        this.function=function;
    }
    public String getFunction(){
        return this.function;
    }
}
