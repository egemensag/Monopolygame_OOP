public class Piece {
    private Square square;
Piece(Square square){ this.square = square; }
    public void setSquare(Square square) {
        this.square = square;
    }
    public Square getSquare() {
        return this.square;
    }
}
